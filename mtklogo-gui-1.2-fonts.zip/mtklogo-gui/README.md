# mtklogo GUI  (v1.2)

> **Novo na 1.2:** a GUI e o script v2 seguem o **idioma do sistema** (português, inglês, alemão, espanhol, francês;
> qualquer outro idioma cai em inglês). Veja "Idiomas" abaixo.
> Na 1.1: AppImage, seletor de conjunto (Original × Sugerido), botão **Escolher logo.bin…**, pasta `sugerido/` e
> correção na detecção de prompts. Detalhes e justificativas em `ANALISE_E_SUGESTOES.md`.

## Idiomas

* Detecção (nesta ordem): `MTKLOGO_GUI_LANG`, `LANGUAGE`, `LC_ALL`, `LC_MESSAGES`, `LANG`; sem tradução → **inglês**.
  Para testar outro idioma sem mudar o sistema: `MTKLOGO_GUI_LANG=de ./mtklogo-gui-1.2-x86_64.AppImage`.
* A GUI passa o idioma escolhido ao script, então os prompts do `sugerido/mtklogos.sh` ficam no mesmo idioma
  (e as perguntas viram `[y/N]`, `[s/N]`, `[j/N]` ou `[o/N]`; a GUI reconhece todas).
  O script **original** (`original/`) e a saída do binário `mtklogo` continuam em inglês: não são traduzíveis sem alterá-los.
* Os botões padrão do Qt (OK, Cancelar, Sim, Não e diálogos de arquivo) também são traduzidos (de, es, fr, pt_BR).
* **Adicionar um idioma** (ex.: italiano, `it`), sem recompilar nada:
  1. `~/mtklogo-gui/lang/it.json` com `{"texto em inglês": "tradução", ...}` (as chaves estão em `CATALOG["pt"]` de `mtklogo_i18n.py`);
  2. `~/mtklogo-gui/lang/it.sh` copiando `sugerido/lang/en.sh` e traduzindo (opcional; sem ele, o script fica em inglês).
  Chaves ausentes caem para o inglês.

## AppImage (mais simples)

```bash
chmod +x mtklogo-gui-1.2-x86_64.AppImage
./mtklogo-gui-1.2-x86_64.AppImage
```
* Na 1ª execução cria `~/mtklogo-gui/original/` e `~/mtklogo-gui/sugerido/` (com um `logo.bin` de **exemplo**). Tudo que o script gera
  (`logo/`, `out/`, `backup/`) fica nessas pastas. Use **Escolher logo.bin…** para trazer o seu.
* Sem FUSE (`libfuse2`)? `./mtklogo-gui-1.2-x86_64.AppImage --appimage-extract-and-run`
* Requer glibc ≥ 2.34 (Ubuntu 22.04+, Debian 12+, Fedora 35+, Arch…) por causa do binário `mtklogo`. Qt/xcb vêm embutidos.

## A partir dos fontes

`./run.sh` abre o conjunto original; **`./run.sh sugerido`** abre o conjunto sugerido (pasta `sugerido/`).

Interface gráfica minimalista (Python + Qt) para o `mtklogos.sh`.
O script roda **exatamente como está** (`bash ./mtklogos.sh`): a GUI só captura a
saída em tempo real e responde às perguntas dele por meio de diálogos.

## Conteúdo

| Arquivo | Descrição |
|---|---|
| `mtklogo_gui.py` | A interface gráfica (PySide6, com fallback para PyQt5) |
| `mtklogo_i18n.py` | Traduções da GUI (pt, de, es, fr; inglês é o padrão) |
| `qt-translations/` | Textos padrão do Qt traduzidos (de, es, fr, pt_BR) |
| `run.sh` | Launcher: usa o Qt do sistema ou cria um `.venv` com PySide6 |
| `requirements.txt` | Dependência Python (`PySide6-Essentials`) |
| `mtklogos.sh` | Script original (**inalterado**) |
| `mtklogo` | Binário Linux x86-64 v1.0.1 (idêntico ao da release mais recente do upstream) |
| `mtklogo.yaml` | Perfis do fork **+ 8 perfis mesclados do upstream** (ver abaixo) |
| `logo.bin` | `logo.bin` de exemplo do repositório (substitua pelo seu) |
| `sugerido/` | `mtklogos.sh` v2.1 (+ `lang/`), `mtklogo.yaml` com correções/perfis `exp_*`, `mtklogo` patchado |
| `mtklogo-improvements.patch` | Patch do código-fonte Rust (aplicar sobre `cyberknight777/mtklogo`) |
| `ANALISE_E_SUGESTOES.md` | Análise do script, yaml e código-fonte |

## Como usar

```bash
unzip mtklogo-gui.zip && cd mtklogo-gui
./run.sh
```

1. Coloque o **seu `logo.bin`** na pasta de trabalho (por padrão, esta mesma pasta;
   dá para trocar em “Pasta…”). Faça backup do original antes de gravar qualquer coisa no aparelho.
2. Clique em **▶ Executar mtklogos.sh**.
3. Quando o script pedir algo, aparece um diálogo:
   * **menu `select`** → lista de opções (duplo clique ou Enter envia);
   * **pergunta de texto** (ex.: largura do aparelho) → campo de texto;
   * **[s/N], (y/n), yes/no** → Sim/Não; **“Press Enter…”** → botão Continuar.
4. **Cancelar** num diálogo pergunta se deseja encerrar o script. O botão **■ Parar** faz o mesmo a qualquer momento.
5. O campo “Entrada manual” permite enviar texto ao script se algo não for detectado.

Atalho no menu de aplicativos (opcional): `./run.sh --install-desktop`

Os arquivos extraídos ficam em `logo/` dentro da pasta de trabalho; o botão **Abrir** abre a pasta no gerenciador de arquivos.

## Requisitos

* Linux, `bash`, Python ≥ 3.8
* Qt: o `run.sh` instala PySide6 num `.venv` local automaticamente (precisa de internet na 1ª vez).
  Se preferir o pacote do sistema: `sudo apt install python3-pyside6.qtwidgets` ou `sudo apt install python3-pyqt5`.
* Se aparecer *“Could not load the Qt platform plugin xcb”*: `sudo apt install libxcb-cursor0`
  (Fedora: `sudo dnf install xcb-util-cursor`).

## Como a GUI detecta as perguntas (sem mexer no script)

* stdout e stderr são unidos num pipe e exibidos ao vivo, com as cores ANSI do script.
* A GUI verifica em `/proc/<pid>/syscall` se algum processo da árvore está bloqueado em `read(0, …)`;
  só então considera que o script espera uma resposta (nunca interrompe o `mtklogo` trabalhando).
* O prompt `#? ` do `select` indica um menu; as linhas `N) opção` anteriores formam a lista.
  O `select` do bash imprime o menu **uma vez só**, então a GUI lembra o menu de cada processo
  (necessário porque o script chama `./mtklogos.sh` recursivamente).
* Única alteração de ambiente: `COLUMNS=1`, para o `select` listar uma opção por linha.
* Limitação do bash: `read -p "texto"` não imprime o prompt quando o stdin não é um terminal.
  O script atual usa `echo -n`, que funciona; em outros scripts, o diálogo genérico mostra a última linha impressa.

## O que foi atualizado do upstream (cyberknight777/mtklogo)

* **`mtklogo` (binário):** o do fork já era byte a byte idêntico (SHA-256 `d85089c2…af56`) ao da release v1.0.1,
  a mais recente. O único commit posterior (`55deb48`, Redmi Note 8 Pro) altera só o `mtklogo.yaml`
  — o binário não embute a configuração — então não há binário novo a trocar.
* **`mtklogo.yaml`:** mantidos todos os perfis do fork (nomes como `720x1280`, usados pelo `mtklogos.sh`) e
  acrescentados os perfis que o upstream tem e o fork não: `cancunf`, `manaus`, `xaga`, `lamu`, `tanzanite`,
  `lg8n`, `s666ln`, `begonia`. O YAML resultante foi validado (23 perfis) e carregado pelo binário.
  Esses perfis não aparecem no menu de resoluções do `mtklogos.sh` (que tem lista fixa);
  usam-se direto na linha de comando: `./mtklogo unpack -p begonia logo.bin -o logo`.

> ⚠ Trocar o logo pode causar bootloop. Faça backup da partição `logo` e use por sua conta e risco.
